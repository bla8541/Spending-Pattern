package com.example.hwi.hw05;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class RegistActivity extends AppCompatActivity {

    private EditText registId;
    private EditText registPw;
    private EditText rePw;
    private EditText gemail;
    private EditText registPhone;
    private Button registBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);

        registId = (EditText) findViewById(R.id.registId);
        registPw = (EditText) findViewById(R.id.registPw);
        rePw = (EditText) findViewById(R.id.rePw);
        gemail = (EditText) findViewById(R.id.registEmail);
        registPhone = (EditText) findViewById(R.id.registPhone);
        registBtn = (Button) findViewById(R.id.registBtn);


        // 비밀번호 일치 검사
        rePw.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String password = registPw.getText().toString();
                String confirm = rePw.getText().toString();

                if (password.equals(confirm)) {
                    registPw.setBackgroundColor(Color.GREEN);
                    rePw.setBackgroundColor(Color.GREEN);
                } else {
                    registPw.setBackgroundColor(Color.RED);
                    rePw.setBackgroundColor(Color.RED);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        registBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // 이메일 입력 확인
                if (registId.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "ID을 입력하세요!", Toast.LENGTH_SHORT).show();
                    registId.requestFocus();
                    return;
                }

                // 비밀번호 입력 확인
                if (registPw.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "비밀번호를 입력하세요!", Toast.LENGTH_SHORT).show();
                    registPw.requestFocus();
                    return;
                }

                // 비밀번호 확인 입력 확인
                if (rePw.getText().toString().length() == 0) {
                    Toast.makeText(RegistActivity.this, "비밀번호 확인을 입력하세요!", Toast.LENGTH_SHORT).show();
                    rePw.requestFocus();
                    return;
                }

                // 비밀번호 일치 확인
                if (!registPw.getText().toString().equals(rePw.getText().toString())) {
                    Toast.makeText(RegistActivity.this, "비밀번호가 일치하지 않습니다!", Toast.LENGTH_SHORT).show();
                    registPw.setText("");
                    rePw.setText("");
                    registPw.requestFocus();
                    return;
                }

                Intent result1 = new Intent();
                Intent result2 = new Intent();
                result1.putExtra("id", registId.getText().toString()); // 아이디
                result2.putExtra("pw", registPw.getText().toString()); // 비밀번호

                try {
                    String id = registId.getText().toString();
                    String pw = registPw.getText().toString();
                    String email = gemail.getText().toString();
                    String phone = registPhone.getText().toString();

                    String result = new RegisterActivity().execute(id, pw, email, phone, "regist").get();
                    // execute : RegisterActivity에서 설정한 매개값을 JSP로 보냄
                    //task.execute(id, pw, phone, "regist");
                    //result = task.execute(id, pw, phone, "regist").get();
                    Log.i("DBtest", "성공!!!!");
                } catch (Exception e) {
                    Log.i("DBtest", ".....ERROR.....!");
                }

                // 자신을 호출한 Activity로 데이터를 보낸다.
                setResult(RESULT_OK, result1);
                // setResult(RESULT_OK. result2);
                finish();
            }
        });


    }
}

