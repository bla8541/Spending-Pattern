package com.example.hwi.hw05;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class SmsActivity extends AppCompatActivity {

    private TextView sender;
    private TextView contents;
    private TextView receivedDate;

    private TextView list;
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Intent intent = getIntent();
        String senderText = intent.getStringExtra("sender");
        String contentsText = intent.getStringExtra("contents");
        String receivedDateText = intent.getStringExtra("receivedDate");

        //list = (TextView) findViewById(R.id.spendlists);

        //String str = senderText + "              " + contentsText + "              " +  receivedDateText;
        //list.setText(receivedDateText + "              " + contentsText + "              " +  contentsText);
        //list.setText(senderText + contentsText + receivedDateText);

        // 지난번 저장해놨던 사용자 입력값을 꺼내서 보여주기
        SharedPreferences sf = getSharedPreferences("sf", MODE_PRIVATE); // sf : 저장소 파일 이름
        sf.getString("name", ""); // 키값(name)으로 꺼냄


        //et.setText(str); // EditText에 반영함

        //sender = (TextView) findViewById(R.id.senderText);
        //sender.setText(senderText);

        contents = (TextView) findViewById(R.id.contentsText);
        contents.setText(receivedDateText + "                          " + contentsText + "                          " +senderText);

        //receivedDate = (TextView) findViewById(R.id.receivedDateText);
        //receivedDate.setText(receivedDateText);

    }


    @Override
    protected void onStop() {
        super.onStop();
        // Activity 가 종료되기 전에 저장한다
        // SharedPreferences 에 설정값(특별히 기억해야할 사용자 값)을 저장하기
        SharedPreferences sf = getSharedPreferences("sf", MODE_PRIVATE);
        SharedPreferences.Editor editor = sf.edit();//저장하려면 editor가 필요
        //String str = list.getText().toString(); // 사용자가 입력한 값
        editor.putString("name", String.valueOf(list)); // 입력
        editor.commit(); // 파일에 최종 반영함
        Toast.makeText(getApplicationContext(), "입력된 항목 저장", Toast.LENGTH_SHORT).show();
    }

    protected void reset(View v) {
        SharedPreferences sf = getSharedPreferences("sf", MODE_PRIVATE);
        SharedPreferences.Editor editor = sf.edit();
        editor.clear();
        editor.commit();
        Toast.makeText(getApplicationContext(), "모든 데이터 삭제", Toast.LENGTH_SHORT).show();
    }


}
