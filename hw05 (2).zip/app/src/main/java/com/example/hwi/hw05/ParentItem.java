package com.example.hwi.hw05;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class ParentItem {
    private String month;
    private String count;

    public ParentItem() {
    }

    public ParentItem(String month, String count) {
        this.month = month;
        this.count = count;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}