package com.example.hwi.hw05;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import static android.widget.Toast.*;

public class LoginActivity extends AppCompatActivity {
    public static final int REQUEST_CODE_MENU=101;
    String userid;
    String userpw;

    private Button btnRegist;
    private Button btnLogin;
    private EditText eid;
    private EditText epw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        eid = (EditText) findViewById(R.id.eid);
        epw = (EditText) findViewById(R.id.epw);
        btnRegist = (Button) findViewById(R.id.regist);
        btnLogin = (Button) findViewById(R.id.gotomenu);
        btnRegist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegistActivity.class);

                // SINGLE_TOP : 이미 만들어진게 있으면 그걸 쓰고, 없으면 만들어서 써라
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

                // 동시에 사용 가능
                // intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);

                // intent를 보내면서 다음 액티비티로부터 데이터를 받기 위해 식별번호(1000)을 준다.
                startActivityForResult(intent, 1000);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.gotomenu:

                        String loginId = eid.getText().toString();
                        String loginPw = epw.getText().toString();

                        //Toast.makeText(LoginActivity.this, "로그인", LENGTH_SHORT).show();
                        //Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                        //startActivity(intent);
                        //finish();



                        try {
                        /*
                        String result;
                        LoginerActivity task = new LoginerActivity();
                        task.execute(loginId, loginPw, "login");
                        result  = task.execute(loginId, loginPw, "login").get();
                        */
                            String result = "";
                            result = new LoginerActivity().execute(loginId, loginPw, "login").get();
                            Log.i("리턴 값", result);

                            //eid.setText(result);


                            if (result.equals("    >true")) {
                                Toast.makeText(LoginActivity.this, "로그인", LENGTH_SHORT).show();
                                Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                                startActivity(intent);
                                finish();
                            } else if (result.equals("    >false")) {
                                Toast.makeText(LoginActivity.this, "아이디 또는 비밀번호가 틀렸습니다.", LENGTH_SHORT).show();
                                eid.setText("");
                                epw.setText("");
                            } else if (result.equals("    >noId")) {
                                Toast.makeText(LoginActivity.this, "존재하지 않는 아이디", LENGTH_SHORT).show();
                                eid.setText("");
                                epw.setText("");
                            }
                        } catch (Exception e) {
                            Log.i("DBtest", e.getMessage());
                            Log.i("DBtest", e.toString());
                            e.printStackTrace();
                        }
                        break;
                }
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // setResult를 통해 받아온 요청번호, 상태, 데이터
        Log.d("RESULT", requestCode + "");
        Log.d("RESULT", resultCode + "");
        Log.d("RESULT", data + "");

        if(requestCode == 1000 && resultCode == RESULT_OK) {
            makeText(LoginActivity.this, "회원가입을 완료했습니다!", LENGTH_SHORT).show();
            eid.setText(data.getStringExtra("id"));
        }

        if (requestCode == REQUEST_CODE_MENU) {
            if (resultCode == RESULT_OK) {
                String menu = data.getExtras().getString("menu");
                makeText(getApplicationContext(), "응답으로 전달된 menu : " + menu, LENGTH_LONG).show();
            }
        }
    }
/*
    public void login(View v) {
        String loginId = eid.getText().toString();
        String loginPw = epw.getText().toString();
        //EditText id = (EditText) findViewById(R.id.eid);
        //EditText pw = (EditText) findViewById(R.id.epw);

        try {
            String result  = new LoginerActivity().execute(loginId, loginPw, "login").get();
            if(result.equals("true")) {
                Toast.makeText(LoginActivity.this,"로그인",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                startActivity(intent);
                finish();
            } else if(result.equals("false")) {
                Toast.makeText(LoginActivity.this,"아이디 또는 비밀번호가 틀렸습니다.",Toast.LENGTH_SHORT).show();
                eid.setText("");
                epw.setText("");
            } else if(result.equals("noId")) {
                Toast.makeText(LoginActivity.this,"존재하지 않는 아이디",Toast.LENGTH_SHORT).show();
                eid.setText("");
                epw.setText("");
            }
        }
        catch (Exception e) {

        }
/*
            if (id.getText().toString().equals(userid)) {
            if (pw.getText().toString().equals(userpw)) {
                Intent intent = new Intent(getApplicationContext(), MenuActivity.class);
                //startActivity(intent);
                startActivityForResult(intent, REQUEST_CODE_MENU);
                //finish();
            } else Toast.makeText(LoginActivity.this, "로그인 실패", Toast.LENGTH_LONG).show();
        } else Toast.makeText(LoginActivity.this, "로그인 실패", Toast.LENGTH_LONG).show();

    } */
}
